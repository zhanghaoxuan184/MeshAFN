from remin.utils import mesh as rm
from remin.solver import Solver, make_trainer
from remin.residual import Residual, make_loader
from remin.solver.residual_loss import EagerLoss, ModLoss
from remin import callbacks
from remin.func import grad
import torch
import numpy as np
from torch import nn
from soft_model import SoftMesh
#from KANLayer import SoftMesh
from hard_model import HardMesh
import matplotlib.pyplot as plt
import matplotlib.tri as tri
import os
import math


#模型3
def imposeHardBC(U_soft, mesh, iter):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    U_p[mesh.find('blr')] = mesh.get('blr')[:,0:2]

    # Ellipse parameters
    a = 0.5  # horizontal radius of the ellipse
    b = 0.2  # vertical radius of the ellipse
    Y_center = 1  # Y coordinate of the ellipse center
    X_center = 1  # X coordinate of the ellipse center

    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0], V_c[:, 1]

    # Calculate Y coordinates of the ellipse for each X_c
    deltaX = X_c - X_center
    Y0 = Y_center - b * np.sqrt(np.clip(1 - (deltaX / a) ** 2, 0, None))
    
    Y0 = np.where(np.abs(deltaX) <= a, Y0, Y_c)

    U_p[mesh.find('top'), 1] = Y0
    U_p[mesh.find('top'), 0] = X_c

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound = U_p[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    dU_bound = dU[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist*dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
            np.multiply(dU_bound, coef).sum(axis=0)
            / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new


#模型4
def imposeHardBC(U_soft, mesh, iter):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    U_p[mesh.find('blr')] = mesh.get('blr')[:, 0:2]

    # Ellipse parameters
    a = 0.5  # horizontal radius of the ellipse
    b = 0.2  # vertical radius of the ellipse
    Y_center = 1  # Y coordinate of the ellipse center
    X_center = 1  # X coordinate of the ellipse center

    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0], V_c[:, 1]

    # Calculate Y coordinates of the ellipse for each X_c
    deltaX = X_c - X_center
    Y0 = Y_center + b * np.sqrt(np.clip(1 - (deltaX / a) ** 2, 0, None))

    Y0 = np.where(np.abs(deltaX) <= a, Y0, Y_c)

    U_p[mesh.find('top'), 1] = Y0
    U_p[mesh.find('top'), 0] = X_c

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound = U_p[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    dU_bound = dU[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist * dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
                np.multiply(dU_bound, coef).sum(axis=0)
                / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new



#模型5
def imposeHardBC(U_soft, mesh, iter):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    U_p[mesh.find('blr')] = mesh.get('blr')[:,0:2]

    # Ellipse parameters
    a = 0.5  # horizontal radius of the ellipse
    b = 0.2  # vertical radius of the ellipse
    Y_center = 1.0  # Y coordinate of the ellipse center
    X_center = 1.0  # X coordinate of the ellipse center

    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0], V_c[:, 1]

    # Calculate Y coordinates of the ellipse for each X_c
    deltaX = X_c - X_center
    Y0 = Y_center - b * np.sqrt(np.clip(1 - (deltaX / a) ** 2, 0, None))
    Y0_line = 0.2 * X_c + 0.6
    Y0 = np.where( X_c <= X_center, Y0, Y0_line)

    U_p[mesh.find('top'), 1] = Y0
    U_p[mesh.find('top'), 0] = X_c

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound = U_p[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    dU_bound = dU[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist*dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
            np.multiply(dU_bound, coef).sum(axis=0)
            / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new

#模型6
def imposeHardBC(U_soft, mesh, iter):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    U_p[mesh.find('blr')] = mesh.get('blr')[:, 0:2]

    # 椭圆参数
    a1 = 0.4  # 椭圆的水平半轴
    b1 = 0.3  # 椭圆的垂直半轴
    Y1_center = 1.0  # 假设正方形顶边的y坐标为1
    X1_center = 0.5  # 假设正方形顶边中心的x坐标为0.5

    a2 = 0.3  # 椭圆的水平半轴
    b2 = 0.2  # 椭圆的垂直半轴
    Y2_center = 1.0  # 假设正方形顶边的y坐标为1
    X2_center = 1.5  # 假设正方形顶边中心的x坐标为0.5

    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0], V_c[:, 1]

    # 计算椭圆内每个点相对于中心的x坐标偏移量
    deltaX1 = X_c - X1_center
    # 计算椭圆形状的y坐标
    Y0_ellipse = Y1_center - b1 * np.sqrt(np.clip(1 - (deltaX1 / a1) ** 2, 0, None))

    # 计算椭圆内每个点相对于中心的x坐标偏移量
    deltaX2 = X_c - X2_center
    # 计算椭圆形状的y坐标
    Y1_ellipse = Y2_center - b2 * np.sqrt(np.clip(1 - (deltaX2 / a2) ** 2, 0, None))

    # 合并两个椭圆的y坐标
    Y0 = np.where((np.abs(deltaX1) <= a1) & (X_c >= 0) & (X_c <= 1.0), Y0_ellipse, Y_c)
    Y0 = np.where((np.abs(deltaX2) <= a2) & (X_c > 1.0), Y1_ellipse, Y0)

    U_p[mesh.find('top'), 1] = Y0
    U_p[mesh.find('top'), 0] = X_c

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound = U_p[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    dU_bound = dU[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist * dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
                np.multiply(dU_bound, coef).sum(axis=0)
                / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new
    
#模型7
def imposeHardBC(U_soft, mesh, iter):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    U_p[mesh.find('blr')] = mesh.get('blr')[:, 0:2]

    # 椭圆参数
    a1 = 0.4  # 椭圆的水平半轴
    b1 = 0.3  # 椭圆的垂直半轴
    Y1_center = 1.0  # 假设正方形顶边的y坐标为1
    X1_center = 0.5  # 假设正方形顶边中心的x坐标为0.5

    a2 = 0.3  # 椭圆的水平半轴
    b2 = 0.2  # 椭圆的垂直半轴
    Y2_center = 1.0  # 假设正方形顶边的y坐标为1
    X2_center = 1.5  # 假设正方形顶边中心的x坐标为0.5

    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0], V_c[:, 1]

    # 计算椭圆内每个点相对于中心的x坐标偏移量
    deltaX1 = X_c - X1_center
    # 计算椭圆形状的y坐标
    Y0_ellipse = Y1_center - b1 * np.sqrt(np.clip(1 - (deltaX1 / a1) ** 2, 0, None))

    # 计算椭圆内每个点相对于中心的x坐标偏移量
    deltaX2 = X_c - X2_center
    # 计算椭圆形状的y坐标
    Y1_ellipse = Y2_center + b2 * np.sqrt(np.clip(1 - (deltaX2 / a2) ** 2, 0, None))

    # 合并两个椭圆的y坐标
    Y0 = np.where((np.abs(deltaX1) <= a1) & (X_c >= 0) & (X_c <= 1.0), Y0_ellipse, Y_c)
    Y0 = np.where((np.abs(deltaX2) <= a2) & (X_c > 1.0), Y1_ellipse, Y0)

    U_p[mesh.find('top'), 1] = Y0
    U_p[mesh.find('top'), 0] = X_c

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound = U_p[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    dU_bound = dU[np.logical_or(mesh.find('blr'), mesh.find('top'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist * dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
                np.multiply(dU_bound, coef).sum(axis=0)
                / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new
    
#四个外边界变化
def imposeHardBC(U_soft, mesh):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    #U_p[mesh.find('lr')] = mesh.get('lr')[:, 0:2]

    #Y_c=1
    V_c = mesh.get('top')[:, 0:2]
    X_c, Y_c = V_c[:, 0:1], V_c[:, 1:2]
    U_p[mesh.find('top'), 1:2] = Y_c - 0.25 * np.sin(np.pi * X_c)
    U_p[mesh.find('top'), 0:1] = X_c

    #Y_b=0
    V_b = mesh.get('bottom')[:, 0:2]
    X_b, Y_b = V_b[:, 0:1], V_b[:, 1:2]
    U_p[mesh.find('bottom'), 1:2] = Y_b+0.25 * np.sin(np.pi * X_b)
    U_p[mesh.find('bottom'), 0:1] = X_b
    temp = U_p[mesh.find('bottom'), 1:2].copy()  # 获取一个副本
    temp[1] = [0]  # 只修改第二个元素
    # 将修改后的值放回原位置
    U_p[mesh.find('bottom'), 1:2] = temp

    # Ellipse parameters
    a = 0.1  # horizontal radius of the ellipse
    b = 0.25  # vertical radius of the ellipse
    Y_center = 0.5  # Y coordinate of the ellipse center
    X_center = 0  # X coordinate of the ellipse center

    V_l = mesh.get('left')[:, 0:2]
    X_l, Y_l = V_l[:, 0], V_l[:, 1]

    # Compute deltaX (distance from the center along the Y direction)
    deltaX = Y_l - Y_center

    # Calculate X0 for the concave ellipse (use negative sign for concave)
    X0 = X_center + a * np.sqrt(np.clip(1 - (deltaX / b) ** 2, 0, None))

    # Apply condition to ensure X0 is within the ellipse range
    X0 = np.where(np.abs(deltaX) <= b, X0, X_l)

    # Update the mesh for the left boundary
    U_p[mesh.find('left'), 1] = Y_l
    U_p[mesh.find('left'), 0] = X0


    # Ellipse parameters
    X1_center = 1  # X coordinate of the ellipse center

    V_r = mesh.get('right')[:, 0:2]
    X_r, Y_r = V_r[:, 0], V_r[:, 1]

    # Compute deltaX (distance from the center along the Y direction)
    deltaX = Y_r - Y_center

    # Calculate X0 for the concave ellipse (use negative sign for concave)
    X1 = X1_center - a * np.sqrt(np.clip(1 - (deltaX / b) ** 2, 0, None))

    # Apply condition to ensure X0 is within the ellipse range
    X1 = np.where(np.abs(deltaX) <= b, X1, X_r)

    # Update the mesh for the left boundary
    U_p[mesh.find('right'), 1] = Y_r
    U_p[mesh.find('right'), 0] = X1

    dU = U_p - U_soft
    U_new = U_p.copy()
    U_bound =  U_p[np.logical_or(np.logical_or(mesh.find('bottom'), mesh.find('left'), mesh.find('top')),mesh.find('right'))]
    dU_bound = dU[np.logical_or(np.logical_or(mesh.find('bottom'), mesh.find('left'), mesh.find('top')),mesh.find('right'))]
    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist * dist).sum(axis=1, keepdims=True)
        # 1/r^2
        coef = np.linalg.norm(distM) / distM
        # [1/r^2 * 1/x, 1/r^2 * 1/y]
        # coef = np.linalg.norm(distM) / distM  * np.linalg.norm(dist) / dist
        # [1/r^2 * exp(-x), 1/r^2 * exp(-y)]
        # coef = np.linalg.norm(distM) / distM * np.exp( - dist / np.linalg.norm(dist))
        shift = (
                np.multiply(dU_bound, coef).sum(axis=0)
                / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new


#圆柱绕流
def imposeHardBC(U_soft, mesh):
    U_p = np.zeros_like(U_soft)
    U_p[mesh.find('pde')] = U_soft[mesh.find('pde')]
    # U_p[mesh.find('lr')] = mesh.get('lr')[:, 0:2]

    U_p[mesh.find('left')] = mesh.get('left')[:, 0:2]
    U_p[mesh.find('right')] = mesh.get('right')[:, 0:2]
    U_p[mesh.find('top')] = mesh.get('top')[:, 0:2]
    U_p[mesh.find('bottom')] = mesh.get('bottom')[:, 0:2]

    # 第一个圆心和半径
    center_x, center_y = 0.4, 0.5
    radius = np.sqrt(2.0 * 0.2 * 0.2)/2.0

    # 上边界
    V_top = mesh.get('hole_top')[:, 0:2]
    X_top, Y_top = V_top[:, 0:1], V_top[:, 1:2]
    val_top = radius**2 - (X_top - center_x)**2
    val_top_clip = np.clip(val_top, 0, None)
    Y_top_new = center_y + np.sqrt(val_top_clip)
    U_p[mesh.find('hole_top'), 0:1] = X_top
    U_p[mesh.find('hole_top'), 1:2] = Y_top_new

    # 下边界
    V_bottom = mesh.get('hole_bottom')[:, 0:2]
    X_bottom, Y_bottom = V_bottom[:, 0:1], V_bottom[:, 1:2]
    val_bottom = radius**2 - (X_bottom - center_x)**2
    val_bottom_clip = np.clip(val_bottom, 0, None)
    Y_bottom_new = center_y - np.sqrt(val_bottom_clip)
    U_p[mesh.find('hole_bottom'), 0:1] = X_bottom
    U_p[mesh.find('hole_bottom'), 1:2] = Y_bottom_new

    # 左边界
    V_left = mesh.get('hole_left')[:, 0:2]
    X_left, Y_left = V_left[:, 0:1], V_left[:, 1:2]
    val_left = radius**2 - (Y_left - center_y)**2
    val_left_clip = np.clip(val_left, 0, None)
    X_left_new = center_x - np.sqrt(val_left_clip)
    U_p[mesh.find('hole_left'), 0:1] = X_left_new
    U_p[mesh.find('hole_left'), 1:2] = Y_left

    # 右边界
    V_right = mesh.get('hole_right')[:, 0:2]
    X_right, Y_right = V_right[:, 0:1], V_right[:, 1:2]
    val_right = radius**2 - (Y_right - center_y)**2
    val_right_clip = np.clip(val_right, 0, None)
    X_right_new = center_x + np.sqrt(val_right_clip)
    U_p[mesh.find('hole_right'), 0:1] = X_right_new
    U_p[mesh.find('hole_right'), 1:2] = Y_right

    dU = U_p - U_soft
    U_new = U_p.copy()
    mask1 = mesh.find('bottom') | mesh.find('left') | mesh.find('top')
    mask2 = mesh.find('hole_bottom') | mesh.find('hole_left') | mesh.find('hole_top')
    mask4 = mesh.find('right') | mesh.find('hole_right')

    mask_total = mask1 | mask2 |mask4

    U_bound = U_p[mask_total]
    dU_bound = dU[mask_total]

    for j in np.arange(U_p.shape[0])[mesh.find('pde', exclude='all')]:
        dist = np.abs(U_bound - U_p[j])
        distM = (dist * dist).sum(axis=1, keepdims=True)
        coef = np.linalg.norm(distM) / distM
        shift = (
                np.multiply(dU_bound, coef).sum(axis=0)
                / coef.sum(axis=0)
        )
        U_new[j] += shift

    return U_new






#模型3
def moving_wall_iter(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:, 0:1], top[:, 1:2]

    # 椭圆参数
    a = 0.5  # 椭圆的水平半轴
    b = 0.2  # 椭圆的垂直半轴
    Y_center = 1.0  # 假设正方形顶边的y坐标为1
    X_center = 1.0  # 假设正方形顶边中心的x坐标为0.5

    def func(iter):
        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX = X_c - X_center
        # 计算椭圆形状的y坐标
        Y0 = Y_center - b * torch.sqrt(torch.clamp(1 - (deltaX / a) ** 2, min=0))
        # 对于不在椭圆区域内的点，保持Y_c不变
        Y0 = torch.where(torch.abs(deltaX) <= a, Y0, Y_c)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func

#模型4
def moving_wall_iter(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:, 0:1], top[:, 1:2]

    # 椭圆参数
    a = 0.5  # 椭圆的水平半轴
    b = 0.2  # 椭圆的垂直半轴
    Y_center = 1.0  # 假设正方形顶边的y坐标为1
    X_center = 1.0  # 假设正方形顶边中心的x坐标为0.5

    def func(iter):
        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX = X_c - X_center
        # 计算椭圆形状的y坐标
        Y0 = Y_center + b * torch.sqrt(torch.clamp(1 - (deltaX / a) ** 2, min=0))
        # 对于不在椭圆区域内的点，保持Y_c不变
        Y0 = torch.where(torch.abs(deltaX) <= a, Y0, Y_c)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func

#模型5
def moving_wall_iter(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:,0:1], top[:,1:2]

    # 椭圆参数
    a = 0.5  # 椭圆的水平半轴
    b = 0.2  # 椭圆的垂直半轴
    Y_center = 1.0  # 假设正方形顶边的y坐标为1
    X_center = 1.0  # 假设正方形顶边中心的x坐标为1

    def func(iter):
        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX = X_c - X_center
        # 计算椭圆形状的y坐标
        Y0_ellipse = Y_center - b * torch.sqrt(torch.clamp(1 - (deltaX / a) ** 2, min=0))
        # 计算直线形状的y坐标
        Y0_line = 0.2 * X_c + 0.6
        # 根据X_c的值决定使用椭圆还是直线的Y坐标
        Y0 = torch.where(X_c <= X_center, Y0_ellipse, Y0_line)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func
    
#模型6
def moving_wall_iter(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:, 0:1], top[:, 1:2]

    # 椭圆参数
    a1 = 0.4  # 椭圆的水平半轴
    b1 = 0.3  # 椭圆的垂直半轴
    Y1_center = 1.0  # 假设正方形顶边的y坐标为1
    X1_center = 0.5  # 假设正方形顶边中心的x坐标为0.5

    a2 = 0.3  # 椭圆的水平半轴
    b2 = 0.2  # 椭圆的垂直半轴
    Y2_center = 1.0  # 假设正方形顶边的y坐标为1
    X2_center = 1.5  # 假设正方形顶边中心的x坐标为0.5


    def func(iter):
        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX1 = X_c - X1_center
        # 计算椭圆形状的y坐标
        Y0_ellipse = Y1_center - b1 * torch.sqrt(torch.clamp(1 - (deltaX1 / a1) ** 2, min=0))

        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX2 = X_c - X2_center
        # 计算椭圆形状的y坐标
        Y1_ellipse = Y2_center - b2 * torch.sqrt(torch.clamp(1 - (deltaX2 / a2) ** 2, min=0))

        # 合并两个椭圆的y坐标
        Y0 = torch.where((torch.abs(deltaX1) <= a1) & (X_c >= 0) & (X_c <= 1.0), Y0_ellipse, Y_c)
        Y0 = torch.where((torch.abs(deltaX2) <= a2) & (X_c > 1.0), Y1_ellipse, Y0)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func
    
#模型7
def moving_wall_iter(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:, 0:1], top[:, 1:2]

    # 椭圆参数
    a1 = 0.4  # 椭圆的水平半轴
    b1 = 0.3  # 椭圆的垂直半轴
    Y1_center = 1.0  # 假设正方形顶边的y坐标为1
    X1_center = 0.5  # 假设正方形顶边中心的x坐标为0.5

    a2 = 0.3  # 椭圆的水平半轴
    b2 = 0.2  # 椭圆的垂直半轴
    Y2_center = 1.0  # 假设正方形顶边的y坐标为1
    X2_center = 1.5  # 假设正方形顶边中心的x坐标为0.5


    def func(iter):
        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX1 = X_c - X1_center
        # 计算椭圆形状的y坐标
        Y0_ellipse = Y1_center - b1 * torch.sqrt(torch.clamp(1 - (deltaX1 / a1) ** 2, min=0))

        # 计算椭圆内每个点相对于中心的x坐标偏移量
        deltaX2 = X_c - X2_center
        # 计算椭圆形状的y坐标
        Y1_ellipse = Y2_center + b2 * torch.sqrt(torch.clamp(1 - (deltaX2 / a2) ** 2, min=0))

        # 合并两个椭圆的y坐标
        Y0 = torch.where((torch.abs(deltaX1) <= a1) & (X_c >= 0) & (X_c <= 1.0), Y0_ellipse, Y_c)
        Y0 = torch.where((torch.abs(deltaX2) <= a2) & (X_c > 1.0), Y1_ellipse, Y0)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func 
    
#四个外边界变化
#上下边界
def moving_wall_iter_top(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:,0:1], top[:,1:2]
    def func(iter):
        Y0 = Y_c - 0.25 * torch.sin(torch.pi * X_c)
        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0
        return moving_wall
    return func


def moving_wall_iter_bottom(bottom):
    bottom = torch.from_numpy(bottom).to(device)
    X_c, Y_c = bottom[:,0:1], bottom[:,1:2]
    def func(iter):
        Y0 = Y_c + 0.25 * torch.sin(torch.pi * X_c)
        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0
        return moving_wall
    return func

#左右边界
# 左边界：构造椭圆曲线
def moving_wall_iter_left(left):
    left = torch.from_numpy(left).to(device)
    X_c, Y_c = left[:, 0:1], left[:, 1:2]

    # 椭圆参数：圆心为(0, 0.5)，长轴为0.1，短轴为0.25
    h = 0  # 圆心X坐标
    k = 0.5  # 圆心Y坐标
    a = 0.1  # 长轴
    b = 0.25  # 短轴

    def func(iter):
        # 计算椭圆曲线上的X坐标 (parametric equation)
        # 对应的X坐标根据Y坐标计算
        X0 = h + a * torch.sqrt(torch.clamp(1 - ((Y_c - k) / b) ** 2, min=0))  # 椭圆方程解X，取负号以生成内凹曲线
        X0 = torch.where(torch.abs(Y_c - k) <= b, X0, X_c)  # 保证Y在椭圆范围内时使用椭圆曲线，否则保持原始值

        # 计算变动的壁面
        def moving_wall(U, x, y):
            X, Y = U
            return X - X0, Y - Y_c

        return moving_wall

    return func

# 右边界：构造椭圆曲线
def moving_wall_iter_right(right):
    right = torch.from_numpy(right).to(device)
    X_c, Y_c = right[:, 0:1], right[:, 1:2]

    # 椭圆参数：圆心为(1, 0.5)，长轴为0.5，短轴为0.2
    h = 1  # 圆心X坐标
    k = 0.5  # 圆心Y坐标
    a = 0.1  # 长轴
    b = 0.25  # 短轴

    def func(iter):
        # 计算椭圆曲线上的X坐标 (parametric equation)
        # 对应的X坐标根据Y坐标计算
        X0 = h - a * torch.sqrt(torch.clamp(1 - ((Y_c - k) / b) ** 2, min=0))  # 椭圆方程解X，取负号以生成内凹曲线
        X0 = torch.where(torch.abs(Y_c - k) <= b, X0, X_c)  # 保证Y在椭圆范围内时使用椭圆曲线，否则保持原始值

        # 计算变动的壁面
        def moving_wall(U, x, y):
            X, Y = U
            return X - X0, Y - Y_c

        return moving_wall

    return func

#圆柱绕流
# 上边界
def moving_wall_iter_hole_top1(top):
    top = torch.from_numpy(top).to(device)
    X_c, Y_c = top[:, 0:1], top[:, 1:2]

    # 圆心坐标
    center_x, center_y = 0.4, 0.5

    def func(iter):
        # 圆弧方程: (X - center_x)^2 + (Y - center_y)^2 = (sqrt(2)/2)^2
        radius = torch.sqrt(torch.tensor(2.0 *0.2 *0.2))/2.0
        Y0 = center_y + torch.sqrt(radius**2 - (X_c - center_x)**2)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func

# 下边界
def moving_wall_iter_hole_bottom1(bottom):
    bottom = torch.from_numpy(bottom).to(device)
    X_c, Y_c = bottom[:, 0:1], bottom[:, 1:2]

    # 圆心坐标
    center_x, center_y = 0.4, 0.5

    def func(iter):
        # 圆弧方程: (X - center_x)^2 + (Y - center_y)^2 = (sqrt(2)/2)^2
        radius = torch.sqrt(torch.tensor(2.0 *0.2 *0.2))/2.0
        Y0 = center_y - torch.sqrt(radius**2 - (X_c - center_x)**2)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X_c, Y - Y0

        return moving_wall

    return func

# 左边界
def moving_wall_iter_hole_left1(left):
    left = torch.from_numpy(left).to(device)
    X_c, Y_c = left[:, 0:1], left[:, 1:2]

    # 圆心坐标
    center_x, center_y = 0.4, 0.5

    def func(iter):
        # 圆弧方程: (X - center_x)^2 + (Y - center_y)^2 = (sqrt(2)/2)^2
        radius = torch.sqrt(torch.tensor(2.0 *0.2 *0.2))/2.0
        X0 = center_x - torch.sqrt(radius**2 - (Y_c - center_y)**2)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X0, Y - Y_c

        return moving_wall

    return func

# 右边界
def moving_wall_iter_hole_right1(right):
    right = torch.from_numpy(right).to(device)
    X_c, Y_c = right[:, 0:1], right[:, 1:2]

    # 圆心坐标
    center_x, center_y = 0.4, 0.5

    def func(iter):
        # 圆弧方程: (X - center_x)^2 + (Y - center_y)^2 = (sqrt(2)/2)^2
        radius = torch.sqrt(torch.tensor(2.0 *0.2 *0.2))/2.0
        X0 = center_x + torch.sqrt(radius**2 - (Y_c - center_y)**2)

        def moving_wall(U, x, y):
            X, Y = U
            return X - X0, Y - Y_c

        return moving_wall

    return func



